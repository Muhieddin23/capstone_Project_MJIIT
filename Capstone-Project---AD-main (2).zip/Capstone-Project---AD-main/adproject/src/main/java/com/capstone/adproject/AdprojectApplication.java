package com.capstone.adproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdprojectApplication.class, args);
	}

}
